// Auto-generated. Do not edit!

// (in-package xela_sensors.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SensName = require('./SensName.js');
let SensPoint = require('./SensPoint.js');

//-----------------------------------------------------------

class SensData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sensor = null;
      this.position = null;
    }
    else {
      if (initObj.hasOwnProperty('sensor')) {
        this.sensor = initObj.sensor
      }
      else {
        this.sensor = new SensName();
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = new SensPoint();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SensData
    // Serialize message field [sensor]
    bufferOffset = SensName.serialize(obj.sensor, buffer, bufferOffset);
    // Serialize message field [position]
    bufferOffset = SensPoint.serialize(obj.position, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SensData
    let len;
    let data = new SensData(null);
    // Deserialize message field [sensor]
    data.sensor = SensName.deserialize(buffer, bufferOffset);
    // Deserialize message field [position]
    data.position = SensPoint.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 18;
  }

  static datatype() {
    // Returns string type for a message object
    return 'xela_sensors/SensData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9d7389b78c6b67d99f807076c5e58d85';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    SensName sensor
    SensPoint position
    
    ================================================================================
    MSG: xela_sensors/SensName
    int16 id
    int16 sensor
    int16 taxel
    ================================================================================
    MSG: xela_sensors/SensPoint
    uint32 x
    uint32 y
    uint32 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SensData(null);
    if (msg.sensor !== undefined) {
      resolved.sensor = SensName.Resolve(msg.sensor)
    }
    else {
      resolved.sensor = new SensName()
    }

    if (msg.position !== undefined) {
      resolved.position = SensPoint.Resolve(msg.position)
    }
    else {
      resolved.position = new SensPoint()
    }

    return resolved;
    }
};

module.exports = SensData;
