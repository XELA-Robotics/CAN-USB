#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist, Vector3
from xela_sensors.srv import XelaSensorZ
import time

class xyz():
    def __init__(self,x,y,z):
        self.x = x
        self.y = y
        self.z = z


rospy.init_node('xSim', anonymous=True)
pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
baseline = []
for i in  range(0,17):
    baseline.append(65535)
rospy.wait_for_service("xServZ")
ser = rospy.ServiceProxy("xServZ",XelaSensorZ)

def serv(x,y):
    val = int(ser(x,y).value)
    if baseline[y] > val and val > 0:
        baseline[y] = val
    out = mapper(val,baseline[y],65535,0.0,2.0,1000)
    #rospy.loginfo("{}/{} IN: {} OUT: {}".format(y,baseline[y],val,out))
    return out

def mapper(val,inmin,inmax,outmin,outmax,treshold):
    if val<inmin+treshold:
        return outmin
    if val>inmax:
        return outmax
    inrange = inmax-inmin
    outrange = outmax-outmin
    inscale = float(val-inmin) / float(inrange)
    return float(outmax + outrange*inscale)

while not rospy.is_shutdown():
    up1 = serv(1,2)
    up2 = serv(1,3)
    left1 = serv(1,5)
    left2 = serv(1,9)
    right1 = serv(1,8)
    right2 = serv(1,12)
    down1 = serv(1,14)
    down2 = serv(1,15)
    updown = float(up1+up2-down1-down2)
    leftright = float((right1+right2-left1-left2))
    #rospy.loginfo("1.2 = {} 1.3 = {}".format(up1,up2))
    #rospy.loginfo("1.5 = {} 1.9 = {}".format(left1,left2))
    #rospy.loginfo("1.8 = {} 1.12 = {}".format(right1,right2))
    #rospy.loginfo("1.14 = {} 1.15 = {}".format(down1,down2))
    pub.publish(xyz(updown,0.0,0.0),xyz(0.0,0.0,leftright))
    #time.sleep(1)
    #pub.publish(xyz(0.0,0.0,0.0),xyz(0.0,0.0,0.0))
    #time.sleep(1)
    time.sleep(0.1)