// Auto-generated. Do not edit!

// (in-package xela_sensors.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class XelaSensorXYstrRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sensortaxel = null;
    }
    else {
      if (initObj.hasOwnProperty('sensortaxel')) {
        this.sensortaxel = initObj.sensortaxel
      }
      else {
        this.sensortaxel = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type XelaSensorXYstrRequest
    // Serialize message field [sensortaxel]
    bufferOffset = _serializer.string(obj.sensortaxel, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type XelaSensorXYstrRequest
    let len;
    let data = new XelaSensorXYstrRequest(null);
    // Deserialize message field [sensortaxel]
    data.sensortaxel = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.sensortaxel.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'xela_sensors/XelaSensorXYstrRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '011da2496e49694a85cbc5a524f23856';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string sensortaxel
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new XelaSensorXYstrRequest(null);
    if (msg.sensortaxel !== undefined) {
      resolved.sensortaxel = msg.sensortaxel;
    }
    else {
      resolved.sensortaxel = ''
    }

    return resolved;
    }
};

class XelaSensorXYstrResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.values = null;
    }
    else {
      if (initObj.hasOwnProperty('values')) {
        this.values = initObj.values
      }
      else {
        this.values = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type XelaSensorXYstrResponse
    // Serialize message field [values]
    bufferOffset = _arraySerializer.uint32(obj.values, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type XelaSensorXYstrResponse
    let len;
    let data = new XelaSensorXYstrResponse(null);
    // Deserialize message field [values]
    data.values = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.values.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'xela_sensors/XelaSensorXYstrResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '32a5ae1cdb19681174e2cdd288a54bfa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32[] values
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new XelaSensorXYstrResponse(null);
    if (msg.values !== undefined) {
      resolved.values = msg.values;
    }
    else {
      resolved.values = []
    }

    return resolved;
    }
};

module.exports = {
  Request: XelaSensorXYstrRequest,
  Response: XelaSensorXYstrResponse,
  md5sum() { return '843fb431c1c0ad8f8bb6abcb3a7be0ef'; },
  datatype() { return 'xela_sensors/XelaSensorXYstr'; }
};
