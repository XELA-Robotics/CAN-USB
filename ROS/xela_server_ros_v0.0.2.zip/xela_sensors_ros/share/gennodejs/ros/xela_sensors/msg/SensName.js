// Auto-generated. Do not edit!

// (in-package xela_sensors.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SensName {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.sensor = null;
      this.taxel = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('sensor')) {
        this.sensor = initObj.sensor
      }
      else {
        this.sensor = 0;
      }
      if (initObj.hasOwnProperty('taxel')) {
        this.taxel = initObj.taxel
      }
      else {
        this.taxel = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SensName
    // Serialize message field [id]
    bufferOffset = _serializer.int16(obj.id, buffer, bufferOffset);
    // Serialize message field [sensor]
    bufferOffset = _serializer.int16(obj.sensor, buffer, bufferOffset);
    // Serialize message field [taxel]
    bufferOffset = _serializer.int16(obj.taxel, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SensName
    let len;
    let data = new SensName(null);
    // Deserialize message field [id]
    data.id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [sensor]
    data.sensor = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [taxel]
    data.taxel = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'xela_sensors/SensName';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e4b57b848d8f35186a6d1f17850a5234';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 id
    int16 sensor
    int16 taxel
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SensName(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.sensor !== undefined) {
      resolved.sensor = msg.sensor;
    }
    else {
      resolved.sensor = 0
    }

    if (msg.taxel !== undefined) {
      resolved.taxel = msg.taxel;
    }
    else {
      resolved.taxel = 0
    }

    return resolved;
    }
};

module.exports = SensName;
