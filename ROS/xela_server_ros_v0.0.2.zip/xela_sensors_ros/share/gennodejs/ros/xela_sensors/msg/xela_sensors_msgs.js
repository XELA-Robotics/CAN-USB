// Auto-generated. Do not edit!

// (in-package xela_sensors.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SensName = require('./SensName.js');
let SensPoint = require('./SensPoint.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class xela_sensors_msgs {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.sensor = null;
      this.position = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('sensor')) {
        this.sensor = initObj.sensor
      }
      else {
        this.sensor = new SensName();
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = new SensPoint();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type xela_sensors_msgs
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [sensor]
    bufferOffset = SensName.serialize(obj.sensor, buffer, bufferOffset);
    // Serialize message field [position]
    bufferOffset = SensPoint.serialize(obj.position, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type xela_sensors_msgs
    let len;
    let data = new xela_sensors_msgs(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [sensor]
    data.sensor = SensName.deserialize(buffer, bufferOffset);
    // Deserialize message field [position]
    data.position = SensPoint.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'xela_sensors/xela_sensors_msgs';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0b756f1ca7e11eb2e39e24a72d33ffda';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    SensName sensor
    SensPoint position
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: xela_sensors/SensName
    int16 id
    int16 sensor
    int16 taxel
    ================================================================================
    MSG: xela_sensors/SensPoint
    int16 x
    int16 y
    int16 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new xela_sensors_msgs(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.sensor !== undefined) {
      resolved.sensor = SensName.Resolve(msg.sensor)
    }
    else {
      resolved.sensor = new SensName()
    }

    if (msg.position !== undefined) {
      resolved.position = SensPoint.Resolve(msg.position)
    }
    else {
      resolved.position = new SensPoint()
    }

    return resolved;
    }
};

module.exports = xela_sensors_msgs;
